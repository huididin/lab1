name:Oliver Ding

files:
src/Core.java: the token enum
src/Main.java: the main method
src/Scanner.java: the original Scanner
src/Parser.java: the Parser
src/ASTNode.java: all the AST nodes class
src/ASTWalker.java: all walkers like pretty Printer and executor

how to compile:
cd src
javac *.java
java Main <code file> <data file>
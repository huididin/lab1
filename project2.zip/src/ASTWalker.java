import java.util.List;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.HashMap;
import java.util.HashSet;

public interface ASTWalker<T> {
    public T walkProg(Prog p);
    public T walkDeclId(DeclId di);
    public T walkDeclFunc(DeclFunc df);
    public T walkAssign(Assign a);
    public T walkIf(If i);
    public T walkLoop(Loop l);
    public T walkIn(In i);
    public T walkOut(Out o);
    public T walkFunc(Func f);
    public T walkCond(Cond c);
    public T walkCmpr(Cmpr c);
    public T walkExpr(Expr e);
    public T walkTerm(Term t);
    public T walkFactor(Factor f);
    public T walkConst(Const c);
    public T walkId(Id i);
}

class ASTPrinter implements ASTWalker<String> {
    private int tabs = 0;
    private String tab() {
        String tab = "";
        for(int i = 0; i < tabs; i++)
            tab += "  ";
        return tab;
    }
    public String walkProg(Prog p) {
        String ret = "program\n";
        tabs++;
        for(Decl d: p.decls)
            ret += d.walk(this);
        ret += "begin\n";
        for(Stmt s: p.stmts)
            ret += s.walk(this);
        tabs--;
        ret += "end\n";
        return ret;
    }
    public String walkDeclId(DeclId di) {
        String ret = tab() + "int ";
        ret += walkIds(di.ids);
        ret += ";\n";
        return ret;
    }
    private String walkIds(List<Id> ids) {
        String ret = "";
        boolean flag = true;
        for(Id i: ids){
            if(flag){
                ret += i.name;
                flag = false;
            }
            else{
                ret += "," + i.name;
            }
        }
        return ret;
    }
    public String walkDeclFunc(DeclFunc df) {
        String ret = tab() + df.fname.name + "(";
        ret += walkIds(df.ids);
        ret += ") begin\n";
        tabs++;
        ret += walkStmts(df.stmts);
        tabs--;
        ret += tab() + "endfunc;\n";
        return ret;
    }
    private String walkStmts(List<Stmt> stmts) {
        String ret = "";
        for(Stmt s: stmts){
            ret += s.walk(this);
        }
        return ret;
    }
    public String walkAssign(Assign a) {
        String ret = "";
        ret += tab() + a.id.name + ":=" + a.expr.walk(this) + ";\n";
        return ret;
    }
    public String walkIf(If i) {
        String ret = "";
        ret += tab() + "if " + i.cond.walk(this) + " then\n";
        tabs++;
        ret += walkStmts(i.stmts);
        tabs--;
        if(i.else_stmts != null){
            ret += tab() + "else\n";
            tabs++;
            ret += walkStmts(i.else_stmts);
            tabs--;
        }
        ret += tab() + "endif;\n";
        return ret;
    }
    public String walkLoop(Loop l) {
        String ret = "";
        ret += tab() + "while " + l.cond.walk(this) + " begin\n";
        tabs++;
        ret += walkStmts(l.stmts);
        tabs--;
        ret += tab() + "endwhile;\n";
        return ret;
    }
    public String walkIn(In i) {
        String ret = "";
        ret += tab() + "input " + walkIds(i.ids) + ";\n";
        return ret;
    }
    public String walkOut(Out o) {
        String ret = "";
        ret += tab() + "output " + o.expr.walk(this) + ";\n";
        return ret;
    }
    public String walkFunc(Func f) {
        String ret = "";
        ret += tab() + "begin " + f.fname.name + "(" + walkIds(f.ids) + ");\n";
        return ret;
    }
    public String walkCond(Cond c) {
        if(c.cond == null){
            return c.cmpr.walk(this);
        }
        else if(c.cmpr == null){
            return "!(" + c.cond.walk(this) + ")";
        }
        else{
            return c.cmpr.walk(this) + " or " + c.cond.walk(this);
        }
    }
    public String walkCmpr(Cmpr c) {
        String ret = c.lexpr.walk(this);
        if(c.op == Core.EQUAL)
            ret += "=";
        else if(c.op == Core.LESS)
            ret += "<";
        else
            ret += "<=";
        ret += c.rexpr.walk(this);
        return ret;
    }
    public String walkExpr(Expr e) {
        String ret = e.term.walk(this);
        if(e.expr == null)
            return ret;
        if(e.op == Core.ADD)
            return ret + "+" + e.expr.walk(this);
        else
            return ret + "-" + e.expr.walk(this);
    }
    public String walkTerm(Term t) {
        String ret = t.factor.walk(this);
        if(t.term == null)
            return ret;
        else
            return ret + "*" + t.term.walk(this);
    }
    public String walkFactor(Factor f) {
        if(f.const_ != null)
            return Integer.toString(f.const_.value);
        else if(f.id != null)
            return f.id.name;
        else
            return "(" + f.expr.walk(this) + ")";
    }
    public String walkConst(Const c) {
        return Integer.toString(c.value);
    }
    public String walkId(Id i) {
        return i.name;
    }
}

class Scope {
    public Scope outer;
    private HashMap<String, Integer> table;
    private HashSet<String> define;
    public Scope(Scope outer){
        this.outer = outer;
        this.table = new HashMap<String, Integer>();
        this.define = new HashSet<String>();
    }
    public void define(String name) {
        if(define.contains(name) || table.containsKey(name)){
            System.out.println("ERROR: double define " + name);
            System.exit(-1);
        }
        define.add(name);
    }
    public void assign(String name, int value) {
        if(define.contains(name)){
            define.remove(name);
            table.put(name, value);
        }
        else if(table.containsKey(name)){
            table.remove(name);
            table.put(name, value);
        }
        else{
            System.out.println("ERROR: undefined " + name);
            System.exit(-1);
        }
    }
    public int get(String name) {
        if(define.contains(name)){
            System.out.println("ERROR: uninitialized " + name);
            System.exit(-1);
        }
        else if(!table.containsKey(name)){
            System.out.println("ERROR: undefined " + name);
            System.exit(-1);
        }
        return table.get(name);
    }
}

class ASTExecutor implements ASTWalker<Integer> {
    private Scanner in;
    private Scope scope;
    private HashMap<String, DeclFunc> funcs = new HashMap<String, DeclFunc>();
    public ASTExecutor(String filename) {
        try {
            this.in = new Scanner(new FileReader(filename));
        } catch (FileNotFoundException e) {
            System.out.println("ERROR: File not found");
            System.exit(-1);
        }
    }
    private int getInteger() {
        if(this.in.hasNextInt()){
            return in.nextInt();
        }
        System.out.println("ERROR: Input doesn't have next Intger");
        System.exit(-1);
        return 0;
    }

    public Integer walkProg(Prog p) {
        this.scope = new Scope(null);
        for(Decl d: p.decls)
            d.walk(this);
        for(Stmt s: p.stmts)
            s.walk(this);
        return 0;
    }
    public Integer walkDeclId(DeclId di) {
        for(Id i: di.ids){
            this.scope.define(i.name);
        }
        return 0;
    }
    public Integer walkDeclFunc(DeclFunc df) {
        this.funcs.put(df.fname.name, df);
        return 0;
    }
    public Integer walkAssign(Assign a) {
        this.scope.assign(a.id.name, a.expr.walk(this));
        return 0;
    }
    public Integer walkIf(If i) {
        int cond = i.cond.walk(this);
        if(cond != 0){
            for(Stmt s: i.stmts)
                s.walk(this);
        }
        else if(i.else_stmts != null){
            for(Stmt s: i.else_stmts)
                s.walk(this);
        }
        return 0;
    }
    public Integer walkLoop(Loop l) {
        int cond = l.cond.walk(this);
        while(cond != 0){
            for(Stmt s: l.stmts)
                s.walk(this);
            cond = l.cond.walk(this);
        }
        return 0;
    }
    public Integer walkIn(In i) {
        for(Id id: i.ids){
            int value = getInteger();
            this.scope.assign(id.name, value);
        }
        return 0;
    }
    public Integer walkOut(Out o) {
        int value = o.expr.walk(this);
        System.out.println(value);
        return 0;
    }
    public Integer walkFunc(Func f) {
        Scope newScope = new Scope(this.scope);
        DeclFunc df = this.funcs.get(f.fname.name);
        if(df == null){
            System.out.println("ERROR: no such function " + f.fname.name);
            System.exit(-1);
        }
        if(df.ids.size() != f.ids.size()){
            System.out.println("ERROR: params not matched");
            System.exit(-1);
        }
        for(int i = 0; i < df.ids.size(); i++){
            newScope.define(df.ids.get(i).name);
            newScope.assign(df.ids.get(i).name, this.scope.get(f.ids.get(i).name));
        }
        this.scope = newScope;
        for(Stmt s: df.stmts){
            s.walk(this);
        }
        newScope = this.scope;
        this.scope = newScope.outer;
        this.scope.assign(f.ids.get(0).name, newScope.get(df.ids.get(0).name));
        return 0;
    }
    public Integer walkCond(Cond c) {
        if(c.cond == null){
            return c.cmpr.walk(this);
        }
        else if(c.cmpr == null){
            int value = c.cond.walk(this);
            if(value == 0)
                return 1;
            else
                return 0;
        }
        else{
            int value1 = c.cmpr.walk(this);
            int value2 = c.cond.walk(this);
            if(value1 == 0 && value2 == 0)
                return 0;
            else
                return 1;
        }
    }
    public Integer walkCmpr(Cmpr c) {
        int value1 = c.lexpr.walk(this);
        int value2 = c.rexpr.walk(this);
        if(c.op == Core.EQUAL){
            if(value1 == value2)
                return 1;
        }
        else if(c.op == Core.LESS){
            if(value1 < value2)
                return 1;
        }
        else if(c.op == Core.LESSEQUAL){
            if(value1 <= value2)
                return 1;
        }
        return 0;
    }
    public Integer walkExpr(Expr e) {
        int value = e.term.walk(this);
        if(e.op == Core.ADD)
            return value + e.expr.walk(this);
        else if(e.op == Core.SUB)
            return value - e.expr.walk(this);
        else
            return value;
    }
    public Integer walkTerm(Term t) {
        int value = t.factor.walk(this);
        if(t.term != null)
            return value * t.term.walk(this);
        else
            return value;
    }
    public Integer walkFactor(Factor f) {
        if(f.const_ != null)
            return f.const_.value;
        if(f.id != null)
            return this.scope.get(f.id.name);
        return f.expr.walk(this);
    }
    public Integer walkConst(Const c) {
        return c.value;
    }
    public Integer walkId(Id i) {
        return this.scope.get(i.name);
    }
}
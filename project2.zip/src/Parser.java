import java.util.List;
import java.util.ArrayList;

public class Parser {
    private final Scanner s;
    private Core token = null;
    public Parser(Scanner s) {
        this.s = s;
    }

    private void next() {
        if(token == null)
            token = s.currentToken();
        else{
            s.nextToken();
            token = s.currentToken();
        }
    }

    private void error(Core... tokens) {
        System.out.println("Error: except " + tokens[0] + " but current token is " + token);
        System.exit(-1);
    }

    private void accept(Core... tokens) {
        for(Core t: tokens){
            if(this.token == t){
                next();
                return;
            }
        }
        error(tokens[0]);
    }

    private boolean check(Core... tokens) {
        for(Core t: tokens){
            if(t == token)
                return true;
        }
        return false;
    }

    public Prog parse() {
        next();
        return prog();
    }

    private Prog prog() {
        accept(Core.PROGRAM);
        List<Decl> decls = decls();
        accept(Core.BEGIN);
        List<Stmt> stmts = stmts();
        accept(Core.END);
        return new Prog(decls, stmts);
    }
    private List<Decl> decls() {
        List<Decl> decls = new ArrayList<Decl>();
        while(check(Core.ID, Core.INT)){
            if(token == Core.ID){
                decls.add(declFunc());
            }
            else{
                decls.add(declId());
            }
        }
        return decls;
    }
    private DeclId declId() {
        accept(Core.INT);
        List<Id> ids = ids();
        accept(Core.SEMICOLON);
        return new DeclId(ids);
    }
    private List<Id> ids() {
        List<Id> ids = new ArrayList<Id>();
        ids.add(new Id(s.getID()));
        accept(Core.ID);
        while(check(Core.COMMA)){
            accept(Core.COMMA);
            ids.add(new Id(s.getID()));
            accept(Core.ID);
        }
        return ids;
    }
    private DeclFunc declFunc() {
        Id fname = new Id(s.getID());
        accept(Core.ID);
        accept(Core.LPAREN);
        List<Id> ids = ids();
        accept(Core.RPAREN);
        accept(Core.BEGIN);
        List<Stmt> stmts = stmts();
        accept(Core.ENDFUNC);
        accept(Core.SEMICOLON);
        return new DeclFunc(fname, ids, stmts);
    }
    private List<Stmt> stmts() {
        List<Stmt> stmts = new ArrayList<Stmt>();
        while(check(Core.ID, Core.BEGIN, Core.INPUT, Core.OUTPUT, Core.IF, Core.WHILE)){
            if(check(Core.ID)){
                stmts.add(assign());
            }
            else if(check(Core.BEGIN)){
                stmts.add(func());
            }
            else if(check(Core.INPUT)){
                stmts.add(in());
            }
            else if(check(Core.OUTPUT)){
                stmts.add(out());
            }
            else if(check(Core.IF)){
                stmts.add(if_());
            }
            else if(check(Core.WHILE)){
                stmts.add(loop());
            }
        }
        return stmts;
    }
    private Stmt assign() {
        Id id = new Id(s.getID());
        accept(Core.ID);
        accept(Core.ASSIGN);
        Expr expr = expr();
        accept(Core.SEMICOLON);
        return new Assign(id, expr);
    }
    private Stmt in() {
        accept(Core.INPUT);
        List<Id> ids = ids();
        accept(Core.SEMICOLON);
        return new In(ids);
    }
    private Stmt out() {
        accept(Core.OUTPUT);
        Expr expr = expr();
        accept(Core.SEMICOLON);
        return new Out(expr);
    }
    private Stmt func() {
        accept(Core.BEGIN);
        Id fname = new Id(s.getID());
        accept(Core.ID);
        accept(Core.LPAREN);
        List<Id> ids = ids();
        accept(Core.RPAREN);
        accept(Core.SEMICOLON);
        return new Func(fname, ids);
    }
    private Stmt if_() {
        accept(Core.IF);
        Cond cond = cond();
        accept(Core.THEN);
        List<Stmt> stmts = stmts();
        List<Stmt> else_stmts = null;
        if(check(Core.ELSE)){
            accept(Core.ELSE);
            else_stmts = stmts();
        }
        accept(Core.ENDIF);
        accept(Core.SEMICOLON);
        return new If(cond, stmts, else_stmts);
    }
    private Stmt loop() {
        accept(Core.WHILE);
        Cond cond = cond();
        accept(Core.BEGIN);
        List<Stmt> stmts = stmts();
        accept(Core.ENDWHILE);
        accept(Core.SEMICOLON);
        return new Loop(cond, stmts);
    }
    private Cond cond() {
        if(check(Core.NEGATION)){
            accept(Core.NEGATION);
            accept(Core.LPAREN);
            Cond cond = cond();
            accept(Core.RPAREN);
            return new Cond(null, cond);
        }
        Cmpr cmpr = cmpr();
        Cond cond = null;
        if(check(Core.OR)){
            accept(Core.OR);
            cond = cond();
        }
        return new Cond(cmpr, cond);
    }
    private Cmpr cmpr() {
        Expr lexpr = expr();
        Core op = token;
        accept(Core.EQUAL, Core.LESS, Core.LESSEQUAL);
        Expr rexpr = expr();
        return new Cmpr(lexpr, op, rexpr);
    }
    private Expr expr() {
        Term term = term();
        if(check(Core.ADD, Core.SUB)){
            Core op = token;
            accept(Core.ADD, Core.SUB);
            Expr expr = expr();
            return new Expr(term, op, expr);
        }
        return new Expr(term, null, null);
    }
    private Term term() {
        Factor factor = factor();
        Term term = null;
        if(check(Core.MULT)){
            accept(Core.MULT);
            term = term();
        }
        return new Term(factor, term);
    }
    private Factor factor() {
        if(check(Core.CONST)){
            Const const_ = new Const(s.getCONST());
            accept(Core.CONST);
            return new Factor(const_, null, null);
        }
        if(check(Core.ID)){
            Id id = new Id(s.getID());
            accept(Core.ID);
            return new Factor(null, id, null);
        }
        if(check(Core.LPAREN)){
            accept(Core.LPAREN);
            Expr expr = expr();
            accept(Core.RPAREN);
            return new Factor(null, null, expr);
        }
        error(Core.CONST, Core.ID, Core.LPAREN);
        return null;
    }
}
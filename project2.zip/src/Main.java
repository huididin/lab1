// Compile with the command "javac *.java"
// Run with the command "java Main FILENAME"
class Main {
  public static void main(String[] args) {
    // Initialize the scanner with the input file
    Scanner S = new Scanner(args[0]);

    Parser parser = new Parser(S);
    Prog program = parser.parse();

    ASTPrinter pretty = new ASTPrinter();
    System.out.print(pretty.walkProg(program));

    ASTExecutor exec = new ASTExecutor(args[1]);
    exec.walkProg(program);
  }
}

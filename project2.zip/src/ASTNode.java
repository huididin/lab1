import java.util.List;

public interface ASTNode {
    public <T> T walk(ASTWalker<T> v);
}

class Prog implements ASTNode {
    public final List<Decl> decls;
    public final List<Stmt> stmts;
    public Prog(List<Decl> decls, List<Stmt> stmts) {
        this.decls = decls;
        this.stmts = stmts;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkProg(this);
    }
}

abstract class Decl implements ASTNode {
    public abstract <T> T walk(ASTWalker<T> w);
}

class DeclId extends Decl {
    public final List<Id> ids;
    public DeclId(List<Id> ids) {
        this.ids = ids;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkDeclId(this);
    }
}

class DeclFunc extends Decl {
    public final Id fname;
    public final List<Id> ids;
    public final List<Stmt> stmts;
    public DeclFunc(Id fname, List<Id> ids, List<Stmt> stmts) {
        this.fname = fname;
        this.ids = ids;
        this.stmts = stmts;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkDeclFunc(this);
    }
}

abstract class Stmt implements ASTNode {
    public abstract <T> T walk(ASTWalker<T> w);
}

class Assign extends Stmt {
    public final Id id;
    public final Expr expr;
    public Assign(Id id, Expr expr) {
        this.id = id;
        this.expr = expr;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkAssign(this);
    }
}

class If extends Stmt {
    public final Cond cond;
    public final List<Stmt> stmts;
    public final List<Stmt> else_stmts;
    public If(Cond cond, List<Stmt> stmts, List<Stmt> else_stmts) {
        this.cond = cond;
        this.stmts = stmts;
        this.else_stmts = else_stmts;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkIf(this);
    }
}

class Loop extends Stmt {
    public final Cond cond;
    public final List<Stmt> stmts;
    public Loop(Cond cond, List<Stmt> stmts) {
        this.cond = cond;
        this.stmts = stmts;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkLoop(this);
    }
}

class In extends Stmt {
    public final List<Id> ids;
    public In(List<Id> ids) {
        this.ids = ids;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkIn(this);
    }
}

class Out extends Stmt {
    public final Expr expr;
    public Out(Expr expr) {
        this.expr = expr;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkOut(this);
    }
}

class Func extends Stmt {
    public final Id fname;
    public final List<Id> ids;
    public Func(Id fname, List<Id> ids) {
        this.fname = fname;
        this.ids = ids;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkFunc(this);
    }
}

class Cond implements ASTNode {
    public final Cmpr cmpr;
    public final Cond cond;
    public Cond(Cmpr cmpr, Cond cond) {
        this.cmpr = cmpr;
        this.cond = cond;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkCond(this);
    }
}

class Cmpr implements ASTNode {
    public final Expr lexpr;
    public final Expr rexpr;
    public final Core op;
    public Cmpr(Expr lexpr, Core op, Expr rexpr) {
        this.lexpr = lexpr;
        this.rexpr = rexpr;
        this.op = op;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkCmpr(this);
    }
}

class Expr implements ASTNode {
    public final Term term;
    public final Expr expr;
    public final Core op;
    public Expr(Term term, Core op, Expr expr) {
        this.term = term;
        this.expr = expr;
        this.op = op;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkExpr(this);
    }
}

class Term implements ASTNode {
    public final Factor factor;
    public final Term term;
    public Term(Factor factor, Term term) {
        this.factor = factor;
        this.term = term;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkTerm(this);
    }
}

class Factor implements ASTNode {
    public final Const const_;
    public final Id id;
    public final Expr expr;
    public Factor(Const const_, Id id, Expr expr) {
        this.const_ = const_;
        this.id = id;
        this.expr = expr;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkFactor(this);
    }
}

class Const implements ASTNode {
    public final int value;
    public Const(int value) {
        this.value = value;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkConst(this);
    }
}

class Id implements ASTNode {
    public final String name;
    public Id(String name) {
        this.name = name;
    }
    public <T> T walk(ASTWalker<T> w) {
        return w.walkId(this);
    }
}